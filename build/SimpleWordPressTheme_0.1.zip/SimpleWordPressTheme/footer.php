<hr />
<div class="container">
    <p class="text-right text-muted">// Proudly powered by Apache, PHP, MySQL, WordPress, Bootstrap, etc,.</p>
</div>
</body>
</html>

